
$(function () {
$("#datepicker").datepicker({
	numberOfMonths: 3,
	dateFormat: 'd MM, yy',
	altField: "#altFormat",
	altFormat: "yy-mm-dd",
	minDate: 0,
	beforeShowDay: function (date) {
		var day = date.getDay();
		return [day == 6, ''];
	}
});
});