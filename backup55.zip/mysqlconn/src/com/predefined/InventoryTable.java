package com.predefined;

import java.io.Serializable;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@SuppressWarnings("serial")
@ManagedBean(name="inventoryTable")
@ApplicationScoped
@SessionScoped

public class InventoryTable implements Serializable {
	
	private String fEED_ID;
	private int wEEK_ENDING_YEAR;
	private int wEEK_ENDING_CC;
	private int wEEK_ENDING_YY;
	private int wEEK_ENDING_MM;
	private int wEEK_ENDING_DD;
	private String dEPARTMENT_FLAG;
	private int cORP;
	private int cOMPANY;
	private int sTORE_NUMBER;
	private int dEPARTMENT;
	private int cHRG_CD_MAJOR;
	private int cHRG_CD_MINOR;
	private int cHRG_CD_SRC;
	private String iTEM_NUMBER;
	private String cOST;
	private String rETAIL;
	private String lEDGER_DESCRIPTION;
	private String vENDOR_NUMBER;
	private String iNVOICE_NUMBER;
	private String pO_NUMBER;
	private String aDJ_REASONS;
	public String getfEED_ID() {
		return fEED_ID;
	}
	public void setfEED_ID(String fEED_ID) {
		this.fEED_ID = fEED_ID;
	}
	public int getwEEK_ENDING_YEAR() {
		return wEEK_ENDING_YEAR;
	}
	public void setwEEK_ENDING_YEAR(int wEEK_ENDING_YEAR) {
		this.wEEK_ENDING_YEAR = wEEK_ENDING_YEAR;
	}
	public int getwEEK_ENDING_CC() {
		return wEEK_ENDING_CC;
	}
	public void setwEEK_ENDING_CC(int wEEK_ENDING_CC) {
		this.wEEK_ENDING_CC = wEEK_ENDING_CC;
	}
	public int getwEEK_ENDING_YY() {
		return wEEK_ENDING_YY;
	}
	public void setwEEK_ENDING_YY(int wEEK_ENDING_YY) {
		this.wEEK_ENDING_YY = wEEK_ENDING_YY;
	}
	public int getwEEK_ENDING_MM() {
		return wEEK_ENDING_MM;
	}
	public void setwEEK_ENDING_MM(int wEEK_ENDING_MM) {
		this.wEEK_ENDING_MM = wEEK_ENDING_MM;
	}
	public int getwEEK_ENDING_DD() {
		return wEEK_ENDING_DD;
	}
	public void setwEEK_ENDING_DD(int wEEK_ENDING_DD) {
		this.wEEK_ENDING_DD = wEEK_ENDING_DD;
	}
	public String getdEPARTMENT_FLAG() {
		return dEPARTMENT_FLAG;
	}
	public void setdEPARTMENT_FLAG(String dEPARTMENT_FLAG) {
		this.dEPARTMENT_FLAG = dEPARTMENT_FLAG;
	}
	public int getcORP() {
		return cORP;
	}
	public void setcORP(int cORP) {
		this.cORP = cORP;
	}
	public int getcOMPANY() {
		return cOMPANY;
	}
	public void setcOMPANY(int cOMPANY) {
		this.cOMPANY = cOMPANY;
	}
	public int getsTORE_NUMBER() {
		return sTORE_NUMBER;
	}
	public void setsTORE_NUMBER(int sTORE_NUMBER) {
		this.sTORE_NUMBER = sTORE_NUMBER;
	}
	public int getdEPARTMENT() {
		return dEPARTMENT;
	}
	public void setdEPARTMENT(int dEPARTMENT) {
		this.dEPARTMENT = dEPARTMENT;
	}
	public int getcHRG_CD_MAJOR() {
		return cHRG_CD_MAJOR;
	}
	public void setcHRG_CD_MAJOR(int cHRG_CD_MAJOR) {
		this.cHRG_CD_MAJOR = cHRG_CD_MAJOR;
	}
	public int getcHRG_CD_MINOR() {
		return cHRG_CD_MINOR;
	}
	public void setcHRG_CD_MINOR(int cHRG_CD_MINOR) {
		this.cHRG_CD_MINOR = cHRG_CD_MINOR;
	}
	public int getcHRG_CD_SRC() {
		return cHRG_CD_SRC;
	}
	public void setcHRG_CD_SRC(int cHRG_CD_SRC) {
		this.cHRG_CD_SRC = cHRG_CD_SRC;
	}
	public String getiTEM_NUMBER() {
		return iTEM_NUMBER;
	}
	public void setiTEM_NUMBER(String iTEM_NUMBER) {
		this.iTEM_NUMBER = iTEM_NUMBER;
	}
	public String getcOST() {
		return cOST;
	}
	public void setcOST(String cOST) {
		this.cOST = cOST;
	}
	public String getrETAIL() {
		return rETAIL;
	}
	public void setrETAIL(String rETAIL) {
		this.rETAIL = rETAIL;
	}
	public String getlEDGER_DESCRIPTION() {
		return lEDGER_DESCRIPTION;
	}
	public void setlEDGER_DESCRIPTION(String lEDGER_DESCRIPTION) {
		this.lEDGER_DESCRIPTION = lEDGER_DESCRIPTION;
	}
	public String getvENDOR_NUMBER() {
		return vENDOR_NUMBER;
	}
	public void setvENDOR_NUMBER(String vENDOR_NUMBER) {
		this.vENDOR_NUMBER = vENDOR_NUMBER;
	}
	public String getiNVOICE_NUMBER() {
		return iNVOICE_NUMBER;
	}
	public void setiNVOICE_NUMBER(String iNVOICE_NUMBER) {
		this.iNVOICE_NUMBER = iNVOICE_NUMBER;
	}
	public String getpO_NUMBER() {
		return pO_NUMBER;
	}
	public void setpO_NUMBER(String pO_NUMBER) {
		this.pO_NUMBER = pO_NUMBER;
	}
	public String getaDJ_REASONS() {
		return aDJ_REASONS;
	}
	public void setaDJ_REASONS(String aDJ_REASONS) {
		this.aDJ_REASONS = aDJ_REASONS;
	}
	
	
	
	

}
