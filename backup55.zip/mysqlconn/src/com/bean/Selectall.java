package com.bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;

import mphasis.logo.Dbconnection;
@ManagedBean
public class Selectall extends Dbconnection {
	private List<Integer> StoreNo;
	private List<String> StoreList;
	public List<Integer> getStoreNo() {
		return StoreNo;
	}
	public void setStoreNo(List<Integer> storeNo) {
		StoreNo = storeNo;
	}
	public List<String> getStoreList() {
		return StoreList;
	}
	public void setStoreList(List<String> storeList) {
		StoreList = storeList;
	}
	
	public List<String> Storeno() throws SQLException{
		StoreNo=new ArrayList<>();

		StoreList=new ArrayList<>();
		
		  Connection con=Dbconnection.getConnection();
		  PreparedStatement ps1=con.prepareStatement("SELECT distinct  sTORE_NUMBER from salesreport.inventory  ");
		  ResultSet rs1=ps1.executeQuery(); 

           while(rs1.next()) {
        	   
        	   StoreList .add(rs1.getString("STORE_NUMBER"));
        	   
           }
		return StoreList;
		
		
		
	}

}
