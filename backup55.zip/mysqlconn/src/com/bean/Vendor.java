package com.bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;

import mphasis.logo.Dbconnection;


@ManagedBean
public class Vendor extends Dbconnection {

	private String vENDOR_NUMBER;

	private List<String> vENDOR_NUMBER_list = new ArrayList<>();

	private String lEDGER_DESCRIPTION;
	
	private List<Integer> dateYY;
	private List<String> dateList;

	private List<String> lEDGER_DESCRIPTION_list = new ArrayList<>();

	public String getvENDOR_NUMBER() {
		return vENDOR_NUMBER;
	}

	public void setvENDOR_NUMBER(String vENDOR_NUMBER) {
		this.vENDOR_NUMBER = vENDOR_NUMBER;
	}

	public List<String> getvENDOR_NUMBER_list() {
		return vENDOR_NUMBER_list;
	}

	public void setvENDOR_NUMBER_list(List<String> vENDOR_NUMBER_list) {
		this.vENDOR_NUMBER_list = vENDOR_NUMBER_list;
	}

	public String getlEDGER_DESCRIPTION() {
		return lEDGER_DESCRIPTION;
	}

	public void setlEDGER_DESCRIPTION(String lEDGER_DESCRIPTION) {
		this.lEDGER_DESCRIPTION = lEDGER_DESCRIPTION;
	}

	public List<String> getlEDGER_DESCRIPTION_list() {
		return lEDGER_DESCRIPTION_list;
	}

	public void setlEDGER_DESCRIPTION_list(List<String> lEDGER_DESCRIPTION_list) {
		this.lEDGER_DESCRIPTION_list = lEDGER_DESCRIPTION_list;
	}
	
	@PostConstruct
    public List<String> changevalue() throws Exception{
System.out.println("=================================ccc");
		  

		dateYY=new ArrayList<>();

		dateList=new ArrayList<>(); 

	       Connection con=Dbconnection.getConnection();

		 PreparedStatement ps1=con.prepareStatement("select * from inventory\r\n" + 
		 		"where concat(WEEK_ENDING_DD,\"/\",WEEK_ENDING_MM,\"/\",WEEK_ENDING_CC,WEEK_ENDING_YY) between '?'  and '?'; ");

		

	           ResultSet rs1=ps1.executeQuery(); 

	           while(rs1.next()) 

	                { 

	            int num1= rs1.getInt(1); //yy
	            int num2= rs1.getInt(2); //mm
	            int num3= rs1.getInt(3); //dd
	           System.out.println(num3+"/"+num2+"/"+num1);

		 

		  String x=Integer.toString(num1); //yy

		  String y=Integer.toString(num2); //mm
	          String z=Integer.toString(num3); //dd

	           String j=z+"/"+y+"/"+x;
	          
	           dateList.add(j);
	           
	           
	           
	                 }

		  return dateList;

		  }


	public List<Integer> getDateYY() {
		return dateYY;
	}

	public void setDateYY(List<Integer> dateYY) {
		this.dateYY = dateYY;
	}

	public List<String> getDateList() {
		return dateList;
	}

	public void setDateList(List<String> dateList) {
		this.dateList = dateList;
	}
}
