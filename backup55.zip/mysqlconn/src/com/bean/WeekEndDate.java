package com.bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import mphasis.logo.Dbconnection;



public class WeekEndDate extends Dbconnection {
	
	private int wEEK_ENDING_YY;
	private int wEEK_ENDING_MM;
	private int wEEK_ENDING_DD;
	
	private List<Integer> wEEK_ENDING_DD_list=new ArrayList<>();
	private List<Integer> wEEK_ENDING_MM_list=new ArrayList<>();
	private List<Integer> wEEK_ENDING_YY_list=new ArrayList<>();
	
	public void setwEEK_ENDING_YY(int wEEK_ENDING_YY) {
		this.wEEK_ENDING_YY = wEEK_ENDING_YY;
	}
	public int getwEEK_ENDING_MM() {
		return wEEK_ENDING_MM;
	}
	public void setwEEK_ENDING_MM(int wEEK_ENDING_MM) {
		this.wEEK_ENDING_MM = wEEK_ENDING_MM;
	}
	public int getwEEK_ENDING_DD() {
		return wEEK_ENDING_DD;
	}
	public void setwEEK_ENDING_DD(int wEEK_ENDING_DD) {
		this.wEEK_ENDING_DD = wEEK_ENDING_DD;
	}
	public List<Integer> getwEEK_ENDING_DD_list() {
		return wEEK_ENDING_DD_list;
	}
	public void setwEEK_ENDING_DD_list(List<Integer> wEEK_ENDING_DD_list) {
		this.wEEK_ENDING_DD_list = wEEK_ENDING_DD_list;
	}
	public List<Integer> getwEEK_ENDING_MM_list() {
		return wEEK_ENDING_MM_list;
	}
	public void setwEEK_ENDING_MM_list(List<Integer> wEEK_ENDING_MM_list) {
		this.wEEK_ENDING_MM_list = wEEK_ENDING_MM_list;
	}
	public List<Integer> getwEEK_ENDING_YY_list() {
		return wEEK_ENDING_YY_list;
	}
	public void setwEEK_ENDING_YY_list(List<Integer> wEEK_ENDING_YY_list) {
		this.wEEK_ENDING_YY_list = wEEK_ENDING_YY_list;
	}
	
	
	
	

}
