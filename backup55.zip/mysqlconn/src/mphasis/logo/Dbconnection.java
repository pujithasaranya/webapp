package mphasis.logo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

import com.bean.UserDefined;

public class Dbconnection {
	private static String driver ="com.mysql.cj.jdbc.Driver";
			private static String username ="root";
			private static String password ="root";
			private static String url ="jdbc:mysql://127.0.0.1:3306/salesreport";
			private static Connection con;
			
			public static Connection getConnection()
			{
				try {
					Class.forName(driver);
						try {
							con = DriverManager.getConnection(url,username,password);
							System.out.println("connected");
							
						} 
						catch (Exception e) {
							System.out.println("An error occurred. Maybe user/password is invalid");
							
						}	
				} 
				catch (Exception e) {
					System.out.println("Could not find database driver class");
					
			}
				return con;
			
			}

			public List<String> get_STORE_NUMBER_name() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getDao(Connection connection, List<UserDefined> UserDefinedList) {
				// TODO Auto-generated method stub
				return null;
			}

			public List<String> get_VendorNo_name() {
				// TODO Auto-generated method stub
				return null;
			}

			public List<Integer> get_VENDOR_NUMBER_name() {
				// TODO Auto-generated method stub
				return null;
			}

			public List<String> get_fEED_ID_name() {
				// TODO Auto-generated method stub
				return null;
			}

			public List<String> get_FEED_ID_name() {
				// TODO Auto-generated method stub
				return null;
			}

			public List<String> get_LEDGER_DESCRIPTION_name() {
				// TODO Auto-generated method stub
				return null;
			}

			
}
